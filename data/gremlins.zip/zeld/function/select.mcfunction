tag @e[type=strawstatues:straw_statue,distance=5] remove selected
tag @n[type=strawstatues:straw_statue] add selected
