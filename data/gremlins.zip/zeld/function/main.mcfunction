say It works!
say run /function zeld:help 