attribute @n[type=strawstatues:straw_statue,tag=selected] minecraft:scale modifier add zeld:scale 1 add_value
attribute @n[type=strawstatues:straw_statue,tag=selected] minecraft:scale modifier remove zeld:scale
$attribute @n[type=strawstatues:straw_statue,tag=selected] minecraft:scale modifier add zeld:scale $(scale) add_value
